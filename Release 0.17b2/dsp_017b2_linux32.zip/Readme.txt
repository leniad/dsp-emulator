                   DSP Emulator v0.17b2 by Leniad 2001-2017

Well, this is just another emulator... but, what's the difference? This is a pascal open source emulator using Delphi/Lazarus environment. There are not many emulators in pascal...
Yes, its open source, you can compile it yourself. But you cannot use it for commercial purposes.
Since version 0.9b3 has ported to Lazarus/Free Pascal, so there is a Linux 32/64bits version available.
Since version 0.14b3 there is a Mac OSX 32bits WIP version.

1-. Emulator
------------
- Can natively handle ZIP format. You can load ROMS, tapes, snapshots or disks from a ZIP files.
- Needed library SDL2: you can download it from the same website emulator or the official website 'www.libsdl.org'. If not present the emulator warns and can not start.

The emulator includes inside the ZIP (not in WIP versions) the ROMS for Spectrum 48K/128K/+3 (and variants), Amstrad CPC 464/664/6128 and Coleco.

IS NOT ALLOWED DISTRIBUTE THIS EMULATOR WITH COPYRIGHTED ROMS

1.1-. Keys
----------
- General Keys
    F1 --> Service key
    F2 --> Full speed/Normal Speed
    F3 --> Reset machine
    F6 --> Full screen
    F7  --> Save quick Snapshot 1
    F8  --> Save quick Snapshot 2
    F9  --> Load quick Snapshot 1
    F10 --> Load quick Snapshot 2
    F11 --> Changes emulation speed from 25%, 50%, 75% and 100%
  Since 0.14b2 some arcade drivers can save/load two quick snapshots
  Since 0.15b1 'Full Screen' works again

- Keys for both players are redefinable, and you can select an external joystick for any player and up to 6 buttons per player
  By default keys are
    Player 1 Up       --> Key 'Cursor UP'
    Player 1 Down     --> Key 'Cursor DOWN'
    Player 1 Left     --> Key 'Cursor LEFT'
    Player 1 Right    --> Key 'Cursor RIGHT'
    Player 1 Button 1 --> Key 'LEFT CONTROL'
    Player 1 Button 2 --> Key 'LEFT ALT'
    Start player 1    --> Key '1'
    Start player 2    --> Key '2'
    Insert coin 1     --> Key '5'
    Insert Coin 2     --> Key '6' 
  Any other control is not defined. You can redefine it in the main configuration menu.
  Since version 17b2 you can select autofire in all players buttons

- Spectrum/Amstrad basic keys
    F1 --> Play/Stop tape
    F4 --> Save snapshot
    F5 --> Remove Disk

1.2-. Language
--------------
DSP is by default in English, if you want to change it using 'File -> Language' or click the Settings button.
You can select 'Castellano', 'Catalan', 'English', 'German', 'French', 'Brazilian' or 'Italian'.
Since 0.17b1 version, languaje files are not needed, they are integrated.

1.3-. Configuration
-------------------
In the main screen of the emulator you can press some buttons
	- Reset/Start/Pause emulation
	- Fastest/Slow emulation
	- General configuration, you can configure some options
		- Select the main language
		- Audio quality: 11025Khz, 22050Khz, 44100Khz or 'No Sound'
		- Video settings: 1x, 2x, scanlines 1x, scanlines 2x or 3x factor
		- Default directories for arcade ROMs, hiscore files, preview images, samples, quick snapshots and NV-Ram files
		- Redefine all keys or use external joystick
		- Load last driver/use driver list
		- Show the ROMs CRC errors
		- Center the main screen when the driver is changed
	- Since 0.16b2 version configuration of drivers has changed as follows:
		- When the running driver is an arcade, there is a button for change the dip switches
		- When the driver wich is running is a computer/console, there is a button to change its specific configuration
	- Show game list:
		- Since version 0.9 the emulator can start whith a list of drivers, which shows the arcade games, computers and consoles available and further information: availability of the ROMS for each system, distribution year, company, etc.
		- In general configuration you can choose this way of booting (show a game list), or the old way (run the last driver loaded)
	- Save Pictures: Since 0.7b2 version you can save GIF, JPG or PNG from all drivers (arcade, computer or console)
	- Export ROMs/samples information: Since 0.16b2 version ROMs/samples information can be exported in .DAT (Clearmame) format to check if any is missing, defective, etc.
	- Autofire: You can configure autofire in any of the buttons of both players

2-. Drivers
-----------

2.1 Computers
-------------

Spectrum 16K, 48K, 128K, +2 and +2A/+3 
**************************************
 - ROMS: You can change Spectrum ROM loading. Configure your favorite ROM or a ZIP file (the name of the ROM inside the ZIP must be the same of ZIP name, for example 'SPECTRUM.ZIP' and the ROM inside the ZIP 'SPECTRUM.ROM')
 - Border: You can choose line by line emulation, pixel by pixel emulation (slowly but more exact) or disable border emulation (fastest).
 - LensLok: The window showing the protection is automatically activated when detecting a tape/disc having this protection, also automatically selects the appropriate game. You can force the display/hide the LensLok protection window, also within the window you can select the game if is not detected correctly.
 - Spectrum 48K issue: Choose Spectrum issue 2 or 3
 - Joystick: Joystick is emulated with the redefinable keys or external joystick. 
   You can choose joystick type:
	- Kempston
	- Cursor/Protek
	- Sinclair 1/Interface 2
	- Sinclair 2/Interface 2
        - Fuller
 - Gunstick/Lightgun: The mouse is used as Gunstick, and left button is used as fire.
 - AMX Mouse/Kempston Mouse: Use the mouse and the buttons.
 - ULA+: Enable/disable ULA+ extended colors. Supported since 0.9b3 version.
 - AY8912 sound: Set the type of channels sound: mono, stereo ABC or stereo ACB
 - Tape loading sound: Enable/disable the sound of the tape when loading.
 - Speaker filter: Enable/disable filter to reduce the noise in speaker emulation.
 - Speaker oversample: Quality of speaker emulation

Other features
 - Keyboard: Corresponds with the PC keyboard keys, also set some special keys:
	- Simbol Shift: Shift key (left or right)
	- Caps Shift: Control key (left or right )
	- Keys on extended models, mapped according to its function
 - Virtual Tapes: Can load ZIP, TAP, TZX, PZX, WAV and CSW. Fully working spectrum load schemes (bleepload, alkatraz, original rom...). 
   With the mouse you can move inside virtual tape and select the start position. Tape begin to play when detects - LOAD "" - and stop when reaches the final.
   If inside the ZIP file there is a ROM file, emulator load first ROM file and then loads then virtual tape.
   Also, if inside the ZIP is a .SCR image, it's used as a preview.
 - Snapshots: you can load Z80, DSP, SNA, SZX, ZX and SP. And you can save in SZX, Z80, DSP and SNA format.
 - Audio: Spectrum beeper and in modern Spectrum revisions there is a AY-8912.
 - Floppy disk: Emulated all NEC-765 functions but write operations. Supports IPF, DSK and 'extended' DSK formats.
 - To do:
	- Contented IO is not working at 100%.

Amstrad CPC 464, 664 and 6128
*****************************
- ROMs: The following options exists:
	- On CPC models 464 and 6128 you can choose the lower ROM corresponding to various regions (UK, French, Spanish or Danish), also on all models you can choose to load a low ROM different from the Amstrad original
	- There are 6 slots available to load additional ROMs
- RAM: You can configure the following memory extensions:
	- Dk'tronics compatible: 512Kb of extra RAM
	- Extension of 4Mb (not working at the moment)
- LensLok: The window showing the protection is automatically activated when detecting a tape/disc having this protection, also automatically selects the appropriate game. You can force the display/hide the LensLok protection window, also within the window you can select the game if is not detected correctly.
- Keyboard: Mapped all keys in a similar position than the CPC. Special cases:
	- F0..F9 CPC function keys are emulated using the numbers on the PC keypad
	- The shift key on the CPC: Mapped on both shift keys (left or right) on the PC keyboard
	- The 'point' button next to the function in the CPC is also mapped into the 'point' PC keypad
	- The 'Enter' key on the numeric keypad PC works also as 'Enter' in the emulation CPC
- Joystick: Emulated with the redefinable keys or external joystick.
- Virtual Tape: you can load ZIP, CDT, WAV and CSW. Work the classical loading squemes (bleepload, alkatraz, SpeedLock ...). Use the mouse to move inside the virtual tape and select the starting position.
- Sound: All version have the AY-8912 chip
- Floppy disk: Emulated the functions of the NEC-765, just missing writing functions. Supports the IPF, DSK and the 'extended' DSK formats.
- Snapshots: Support load/save 'SNA' format
- To do:
	- Some disk protections are not working (a few left)
	- Some video effect are missing (M6845 chip)

2.2 Consoles
------------

NES
***
- Cartridge: Supports '.nes' ROM format, compressed or not.
- Keys: Use the redefined keys or external joystick
	'SELECT' uses coin 1 (by default is mapped as key '5')
	'START' uses start player 1 (by default is mapped as the '1' key).
- Sound: Support sound
- Mappers: Supports 0,1,2,3,4,7,9,12,66,67 (partial),68,71,87,93,94,180 and 185
- To Do
	- Snapshots
	- Add more mappers
	- Video Timings

GameBoy/GameBoy Color
***********************
- ROMs: Not required, but if present are loaded and run as the original console.
- Keys: Use the redefined keys or the external joystick
	'SELECT' uses coin 1 (by default is mapped as key '5')
	'START' uses start player 1 (by default is mapped as the '1' key).
- Cartridges: Supports cartridges '.gb' and '.gbc', compressed or not.
- Mappers supported are MBC0, MBC1, MBC2, MBC5 and HuC-1
- To Do
	- Snapshots
	- Audio problems, do not work fine with high frequencies
	- Video Timings
	- Add more mappers

Coleco Vision
*************
- ROM: The ROM is needed for emulation
- Keys: Joystick is emulated with the redefinable keys or external joystick (the secondary joystick does not have keys assigned). Does not support (still) the special joysticks.
  The numbers on the keyboard from '1' to '0' emulate the number keys.
  Keys 'Q' and 'W' emulate the keys '*' and '#'
- Cartridges: It supports the standard game cartridges (not expansion cartridges) with 'ROM' and 'COL' file extension compressed or not
- Sound: Support the sound AY-8912 chip
- Snapshot: Load/save snapshots with my own format. When the snapshot is loaded includes the ROM cartridge, so they are independent and can be loaded without the original cartridge.

Chip 8/Super Chip8
******************
- ROM: Does not have. It's a simulation of a pseudo CPU.
- Keyboard: Mapped the system keys
    Original    Real Keyboard
    1 2 3 A --> 1 2 3 4
    4 5 6 B --> Q W E R
    7 8 9 C --> A S D F
    D 0 E F --> Z X C V
- Sound: basic sound mono supported
- Video: Supports 64x32 format from Chip8, 64x64 from Chip8 Hires and 128x64 from SuperChip8
- Files: Supports '.CH8' y '.BIN' formats
- To do
	- Snapshots

Sega Master System
******************
- ROM: It is not necessary for the emulation, but is recommended.
- Keys: Use the redefined keys or the external joystick
	'SELECT' uses coin 1 (by default is mapped as key '5')
	'START' uses start player 1 (by default is mapped as the '1' key).
- Sound: Sound chip SN76496 implemented
- Cartridges: Supports cartridges '.sms' and '.sg' (partialy), compressed or not.
- Video: Supports all video special SMS video modes, and all the original. Supports NTSC and PAL.
- To do
	- Snapshots

2.3 Arcade
----------

2.3.1 Samples
-------------
Some games, given the difficulty of emulating old sound systems, uses 'samples'. Such files are portions of digitized sound, played instead of emulating the sound system.
Currently only some drivers use wholly or partly this system.
If you want the emulator to use the samples, put the compressed sample files with the same name as the ROM in a folder named 'samples'.
You can download all the samples from the emulator page
Look at the arcade systems list to know which systems use samples.

2.3.2 Emulated Systems
----------------------

Name                       | ROM          | Completed  | Notes
----------------------------------------------------------------------------------------------------------------------------------------
Phoenix                    | PHOENIX.ZIP  |      99    | Phoenix HW
                                                       | Preliminary analog sound
Pleiads                    | PLEAIDS.ZIP  |      80    | Phoenix HW
                                                       | No sound
Bombjack                   | BOMBJACK.ZIP |     100    |
Pac-man                    | PACMAN.ZIP   |     100    | Pac-man HW
Ms. Pac-man                | MSPACMAN.ZIP |     100    | Pac-man HW
Crush Roller               | CRUSH.ZIP    |     100    | Pac-man HW
Mysterious Stones          | MYSTSTON.ZIP |     100    |
Frogger                    | FROGGER.ZIP  |     100    | Galaxian HW
Galaxian                   | GALAXIAN.ZIP |      95    | Galaxian HW
                                                       | Partial sound with samples
Jump Bug                   | JUMPBUG.ZIP  |     100    | Galaxian HW
Moon Cresta                | MOONCRST.ZIP |      90    | Galaxian HW
                                                       | Partial sound with samples
Scramble                   | SCRAMBLE.ZIP |     100    | Galaxian HW
Super Cobra                | SCOBRA.ZIP   |     100    | Galaxian HW
Amidar                     | AMIDAR.ZIP   |     100    | Galaxian HW
Donkey Kong                | DKONG.ZIP    |     100    | DK HW
                           |              |            | Full sound using samples
Donkey Kong Junior         | DKONGJR.ZIP  |     100    | DK HW
                           |              |            | Full sound using samples
Donkey Kong 3              | DKONG3.ZIP   |     100    | DK  HW
Black Tiger                | BLKTIGER.ZIP |     100    |
Green Beret                | GBERET.ZIP   |     100    | Green Beret HW
Mr. Goemon                 | MRGOEMON.ZIP |     100    | Green Beret HW
Commando                   | COMMANDO.ZIP |     100    |
Ghost'n'Goblins            | GNG.ZIP      |     100    |
Mikie                      | MIKIE.ZIP    |     100    |
Shaolin's Road             | SHAOLIN.ZIP  |     100    |
Yie Ar Kung-Fu             | YIEAR.ZIP    |     100    |
Son Son                    | SONSON.ZIP   |     100    |
Asteroids                  | ASTEROID.ZIP |     100    | Analog sound and samples
Lunar Lander               | LLANDER.ZIP  |      50    | No sound, graphics problems
Star Force                 | STARFORC.ZIP |     100    | 
Rygar                      | RYGAR.ZIP    |     100    | Tecmo HW
Silk Worm                  | SILKWORM.ZIP |     100    | Tecmo HW
Pitfall II                 | PITFALL2.ZIP |     100    | Sega System 1 HW
Teddy Boy Blues            | TEDDYBB.ZIP  |     100    | Sega System 1 HW
Wonder Boy                 | WBOY.ZIP     |     100    | Sega System 1 HW
Wonder Boy in Monster Land | WBML.ZIP     |     100    | Sega System 2 HW
Choplifter                 | CHOPLIFT.ZIP |     100    | Sega System 2 HW
Mister Viking              | MRVIKING.ZIP |     100    | Sega System 1 HW
Sega Ninja                 | SEGANINJ.ZIP |     100    | Sega System 1 HW
Up'n Down                  | UPNDOWN.ZIP  |     100    | Sega System 1 HW
Flicky                     | FLICKY.ZIP   |     100    | Sega System 1 HW
Pooyan                     | POOYAN.ZIP   |     100    | 
Jungler                    | JUNGLER.ZIP  |     100    | Rally X HW
Rally X                    | RALLYX.ZIP   |     100    | Rally X HW
                                                       | Explosion sound uses samples
New Rally X                | NRALLYX.ZIP  |     100    | Rally X HW
                                                       | Explosion sound uses samples
City Connection            | CITYCON.ZIP  |     100    |
Burger Time                | BTIME.ZIP    |     100    |
Express Raider             | EXPRRAID.ZIP |     100    |
Super Basketball           | SBASKETB.ZIP |     100    |
Lady Bug                   | LADYBUG.ZIP  |     100    | Lady Bug HW
Snap Jack                  | SNAPJACK.ZIP |     100    | Lady Bug HW
Cosmic Avenger             | CAVENGER.ZIP |     100    | Lady Bug HW
Tehkan World Cup           | TEHKANWC.ZIP |     100    |
Popeye                     | POPEYE.ZIP   |     100    |
Psychic 5                  | PSYCHIC5.ZIP |      96    | Missing Alpha render (background and sprites) and colour intensity
Kung-Fu Master             | KUNGFUM.ZIP  |     100    | Irem M62 HW
Spelunker                  | SPELUNKR.ZIP |     100    | Irem M62 HW
Spelunker II               | SPELUNK2.ZIP |     100    | Irem M62 HW
Lode Runner                | LODERUN.ZIP  |     100    | Irem M62 HW
Lode Runner II             | LODERUN2.ZIP |     100    | Irem M62 HW
Terra Cresta               | TERRACRE.ZIP |     100    |
Shoot Out!                 | SHOOTOUT.ZIP |     100    |
Vigilante                  | VIGILANT.ZIP |     100    |
Jackal                     | JACKAL.ZIP   |     100    |
Bubble Bobble              | BUBLBOBL.ZIP |     100    |
Prehistoric Isle in 1930   | PREHISLE.ZIP |     100    |
Tiger Road                 | TIGEROAD.ZIP |     100    | Tiger Road HW
F1 Dream                   | F1DREAM.ZIP  |     100    | Tiger Road HW
Snow Bros                  | SNOWBROS.ZIP |     100    |
Toki                       | TOKI.ZIP     |     100    |
Contra                     | CONTRA.ZIP   |     100    |
Mappy                      | MAPPY.ZIP    |     100    | Mappy HW
Dig-Dug II                 | DIGDUG2.ZIP  |     100    | Mappy HW
Super Pacman               | SUPERPAC.ZIP |     100    | Mappy HW
The Tower of Druaga        | TODRUAGA.ZIP |     100    | Mappy HW
Motos                      | MOTOS.ZIP    |     100    | Mappy HW
Rastan                     | RASTAN.ZIP   |     100    |
Legendary Wings            | LWINGS.ZIP   |     100    | Legendary Wings HW
Section Z                  | SECTIONZ.ZIP |     100    | Legendary Wings HW
Trojan                     | TROJAN.ZIP   |     100    | Legendary Wings HW
Street Fighter             | SF.ZIP       |     100    |
Galaga                     | GALAGA.ZIP   |     100    | Galaga HW
                                                       | Partial sound using samples
DigDug                     | DIGDUG.ZIP   |     100    | Galaga HW
Xevious                    | XEVIOUS.ZIP  |      90    | Galaga HW
                                                       | Partial sound using samples
                                                       | Problems with the scroll and sound
Xain'd Sleena              | XSLEENA.ZIP  |     100    |
Hard Head                  | HARDHEAD.ZIP |     100    | Suna HW
Hard Head 2                | HARDHED2.ZIP |      10    | Suna HW
                                                       | Basic driver
Saboten Bombers            | SABOTENB.ZIP |     100    | NMK 16 HW
Bomb Jack Twin             | BJTWIN.ZIP   |     100    | NMK 16 HW
Knuckle Joe                | KNCLJOE.ZIP  |     100    |
Wardner                    | WARDNER.ZIP  |     100    |
Big Karnak                 | BIGKARNC.ZIP |     100    | Gaelco HW
Thunder Hoop               | THOOP.ZIP    |     100    | Gaelco HW
Squash                     | SQUASH.ZIP   |     100    | Gaelco HW
Biomechanical Toy          | BIOMTOY.ZIP  |     100    | Gaelco HW
Exed Exes                  | EXEDEXES.ZIP |     100    |
Gun.Smoke                  | GUNSMOKE.ZIP |     100    | Gun.Smoke HW
1943: The Battle of Midway | 1943.ZIP     |     100    | Gun.Smoke HW
1943 Kai: Midway Kaisen    | 1943KAI.ZIP  |     100    | Gun.Smoke HW
1942                       | 1942.ZIP     |     100    |
Jail Break                 | JAILBREK.ZIP |     100    |
Circus Charlie             | CIRCUSC.ZIP  |     100    |
Iron Horse                 | IRONHORS.ZIP |     100    |
R-Type                     | RTYPE.ZIP    |      95    | Irem M72 HW
Hammerin' Harry            | HHARRY.ZIP   |      95    | Irem M72 HW
R-Type 2                   | RTYPE2.ZIP   |      95    | Irem M72 HW
Break Thru                 | BRKTHRU.ZIP  |     100    | Break Thru HW
Darwin 4078                | DARWIN.ZIP   |     100    | Break Thru HW
Super Real Darwin          | SRDARWIN.ZIP |     100    |
Double Dragon              | DDRAGON.ZIP  |     100    | Double Dragon HW
Double Dragon II -         | 
  The Revenge              | DDRAGON2.ZIP |     100    | Double Dragon HW
Mr. Do!                    | MRDO.ZIP     |     100    |
The Glob                   | THEGLOB.ZIP  |     100    | Epos HW
Super Glob                 | SUPRGLOB.ZIP |     100    | Epos HW
Tiger Heli                 | TIGERH.ZIP   |     100    | Slap Fight HW
Slap Fight                 | SLAPFIGH.ZIP |     100    | Slap Fight HW
The Legend of Kage         | LKAGE.ZIP    |     100    |
Cabal                      | CABAL.ZIP    |     100    |
Ghouls and Ghosts          | GHOULS.ZIP   |     100    | Capcom Play System 1 - CPS1
Final Fight                | FFIGHT.ZIP   |     100    | Capcom Play System 1 - CPS1
The King of Dragons        | KOD.ZIP      |     100    | Capcom Play System 1 - CPS1
                                                       | Missing third player controls
Street Fighter II          |
   The World Warrior       | SF2.ZIP      |      95    | Capcom Play System 1 - CPS1
                                                       | Missing some controls and scroll row
Strider                    | STRIDER.ZIP  |     100    | Capcom Play System 1 - CPS1
Three Wonders              | 3WONDERS.ZIP |     100    | Capcom Play System 1 - CPS1
Captain Commando           | CCOMANDO.ZIP |     100    | Capcom Play System 1 - CPS1
Knights of the Round       | KNIGHTS.ZIP  |     100    | Capcom Play System 1 - CPS1
Street Fighter II'         |
   Champion Edition        | SF2CE.ZIP    |      95    | Capcom Play System 1 - CPS1
                                                       | Missing some controls and scroll row
Cadillacs and Dinosaurs    | DINO.ZIP     |     100    | Capcom Play System 1 - CPS1
The Punisher               | PUNISHER.ZIP |     100    | Capcom Play System 1 - CPS1
Shinobi                    | SHINOBI.ZIP  |      95    | Sega System 16A
                                                       | Missing PCM Sound
Alex Kidd                  | ALEXKIDD.ZIP |      95    | Sega System 16A
                                                       | Missing PCM Sound
Fantasy Zone               | FANTZONE.ZIP |      95    | Sega System 16A
                                                       | Missing PCM Sound
Alien Syndrome             | ALIENSYN.ZIP |      95    | Sega System 16A
                                                       | Missing PCM Sound
Wonder Boy III             | WB3.ZIP      |      95    | Sega System 16A
                                                       | Missing PCM Sound
Time Pilot '84             | TP84.ZIP     |     100    |
Tutankham                  | TUTANKHM.ZIP |     100    |
Pang                       | PANG.ZIP     |      95    | Missing YM2413
Super Pang                 | SPANG.ZIP    |      95    | Missing YM2413
Ninja Kid II               | NINJAKD2.ZIP |      95    | UPL HW
                                                       | No PCM sound
Ark Area                   | ARKAREA.ZIP  |     100    | UPL HW
Mutant Night               | MNIGHT.ZIP   |     100    | UPL HW
Sky Kid                    | SKYKID.ZIP   |     100    | Sky Kid HW
Dragon Buster              | DRGNBSTR.ZIP |     100    | Sky Kid HW
Rolling Thunder            | RTHUNDER.ZIP |     100    | Namco System 86 HW
Hopping Mappy              | HOPMAPPY.ZIP |     100    | Namco System 86 HW
Sky Kid Deluxe             | SKYKIDDX.ZIP |     100    | Namco System 86 HW
Roc'n Rope                 | ROCNROPE.ZIP |     100    |
Repulse                    | REPULSE.ZIP  |     100    |
The NewZealand Story       | TNZS.ZIP     |     100    | TNZS HW
Insector X                 | INSECTX.ZIP  |     100    | TNZS HW
Pacland                    | PACLAND.ZIP  |     100    |
Mario Bros.                | MARIO.ZIP    |     100    | Full sound using samples
Solomon Key                | SOLOMON.ZIP  |     100    |
Combat School              | COMBATSC.ZIP |     100    |
Heavy Unit                 | HVYUNIT.ZIP  |     100    |
P.O.W. - Prisoners of War  | POW.ZIP      |     100    | SNK 68K HW
Street Smart               | STREETSM.ZIP |     100    | SNK 68K HW
Ikari III - The Rescue     | IKARI3.ZIP   |     100    | SNK 68K HW
Search and Rescue          | SEARCHAR.ZIP |     100    | SNK 68K HW
P47 - Phantom Fighter      | P47.ZIP      |     100    | Jaleco Megasystem HW
Rodland                    | RODLAND.ZIP  |     100    | Jaleco Megasystem HW
Saint Dragon               | STDRAGON.ZIP |     100    | Jaleco Megasystem HW
Time Pilot                 | TIMEPLT.ZIP  |     100    |
Pengo                      | PENGO.ZIP    |     100    |
Twin Cobra                 | TWINCOBR.ZIP |     100    | Twin Cobra HW
Flying Shark               | FSHARK.ZIP   |     100    | Twin Cobra HW
Jr. Pac-Man                | JRPACMAN.ZIP |     100    |
Robocop                    | ROBOCOP.ZIP  |     100    | Deco0 HW
Baddudes vs. DragonNinja   | BADDUDES.ZIP |     100    | Deco0 HW
Hippodrome                 | HIPPODRM.ZIP |     100    | Deco0 HW
Tumble Pop                 | TUMBLEP.ZIP  |     100    |
Funky Jet                  | FUNKYJET.ZIP |     100    |
Super Burger Time          | SUPBTIME.ZIP |     100    |
Caveman Ninja              | CNINJA.ZIP   |     100    | Caveman Ninja HW
Robocop 2                  | ROBOCOP2.ZIP |      95    | Caveman Ninja HW
                                                       | Some graphics problems
Diet Go Go                 | DIETGO.ZIP   |     100    |
Act-Fancer Cybernetick     | 
    Hyper Weapon           | ACTFANCR.ZIP |     100    |
Arabian                    | ARABIAN.ZIP  |     100    |
Pirate Ship Higemaru       | HIGEMARU.ZIP |     100    |
Bagman                     | BAGMAN.ZIP   |      95    | Bagman HW
                                                       | Missing TSM 5110 sound
Super Bagman               | SBAGMAN.ZIP  |      95    | Bagman HW
                                                       | Missing TSM 5110 sound
Congo Bongo                | CONGO.ZIP    |     100    | Zaxxon HW
Zaxxon                     | ZAXXON.ZIP   |     100    | Zaxxon HW
Kangaroo                   | KANGAROO.ZIP |     100    |
Bionic Commando            | BIONICC.ZIP  |     100    |
WWF Super Stars            | WWFSSTAR.ZIP |     100    |
Rainbow Islands            | RAINBOW.ZIP  |     100    | Rainbow Islands HW
Rainbow Islands Extra      | RAINBOWE.ZIP |     100    | Rainbow Islands HW
Volfied                    | VOLFIED.ZIP  |     100    |
Operation Wolf             | OPWOLF.ZIP   |     100    | Use the mouse to move the gun cross
Outrun                     | OUTRUN.ZIP   |      10    | Basic Driver
Jungle King                | JUNGLEK.ZIP  |     100    | Taito SJ HW
Elevator Action            | ELEVATOR.ZIP |     100    | Taito SJ HW
Vulgus                     | VULGUS.ZIP   |     100    |
Double Dragon III:         |
    The Rosetta Stone      | DDRAGON3.ZIP |     100    | DD3 HW
The Combatribes            | CTRIBE.ZIP   |     100    | DD3 HW
Block Out                  | BLOCKUOT.ZIP |     100    |
Food Fight                 | FOODF.ZIP    |     100    |
Nemesis                    | NEMESIS.ZIP  |     100    | Nemesis HW
TwinBee                    | TWINBEE.ZIP  |      80    | Nemesis HW
                                                       | Sprites and video video problems
Pirates                    | PIRATES.ZIP  |     100    | Pirates HW
Genis Family               | GENIX.ZIP    |     100    | Pirates HW
Juno First                 | JUNOFRST.ZIP |     100    |
Gyruss                     | GYRUSS.ZIP   |     100    |
Free Kick                  | FREEKICK.ZIP |     100    |
Boogie Wings               | BOOGIEW.ZIP  |      20    | Basic driver
Pinball Action             | PBACTION.ZIP |     100    |
Renegade                   | RENEGADE.ZIP |     100    |
Teenage Mutant Ninja       |
   Turtles                 | TMNT.ZIP     |     100    | TMNT HW
Sunset Riders              | SSRIDERS.ZIP |     100    | TMNT HW
Gradius III                | GRADIUS3.ZIP |     100    |
Space Invaders             | INVADERS.ZIP |     100    | Full sound using samples
Centipede                  | CENTIPED.ZIP |     100    |
Karnov                     | KARNOV.ZIP   |     100    | Karnov HW
Chelnov                    | CHELNOV.ZIP  |     100    | Karnov HW
Aliens                     | ALIENS.ZIP   |      95    | Small sprites priority problems
Super Contra               | SCONTRA.ZIP  |     100    | Thunder Cross HW
Gang Busters               | GBUSTERS.ZIP |     100    | Thunder Cross HW
Thunder Cross HW           | THUNDERZ.ZIP |     100    | Thunder Cross HW
The Simpsons               | SIMPSONS.ZIP |      90    | Some video problems (CPU bug?)
Track & Field              | TRACKFLD.ZIP |     100    |
Hyper Sports               | HYPERSPT.ZIP |     100    |
Megazone                   | MEGAZONE.ZIP |     100    |
Space Fire Bird            | SPACEFB.ZIP  |     100    | Partial sound using samples
Ajax                       | AJAX.ZIP     |      50    | Without sprites or sound. Graphics problems
Vendetta                   | VENDETTA.ZIP |     100    |
-------------------------------------------------------------------------------------------------------------------------------------
Total: 225

3-. Contribute/Code distribution
--------------------------------
If you want to add another language, edit any file with the extension '.lng' in the 'LNG' directory, rename it with the name of the language and send it to me to add it to the next version.
If you make any improvements to any driver, processor, main code, etc. or add drivers, please send the changes to me, so they can be added to the main code.
If you use part of the code of the emulator for any non commercial purpose, you only need to add in the documentation/source something like 'Z80 core written by Leniad'. And please send me a email to see the written program. :-)

4-. Acknowledgments
-------------------
- First, of course, the MAME team. Without them, this emulator never had existed, thanks to distribute the source code to help many people, people like me. (And of course the 'MAME guru' Nicola Salmoria). 
- Chris Cowley, author of VBSpec, from where I've pick a lot of information about Spectrum. In addition I've also got the part of the AY-3-8912 of its emulator, which is an excellent conversion that comes with MAME. 
- Raul Gomez Sanchez author of the R80, one of the best Spectrum emulators for DOS, which use your debugger to trace errors in my emulator Z80. 
- World of Spectrum, they have many tapes, snapshots, in addition many technical information, including the format TZX, DSK, Z80, etc.
- javi[@]fsmail.net that helped me in a moment of desperation with directSound.
- Michael Franzen, who sent me drivers for Pooyan, Coleco, System1, Chip8 and many others to be included in DSP. 
- Tom Walker, he sent me his driver CPS1 where I got and understood a lot of information.
- sremulador, for begin the rewriting of NES driver
- Martijn, from Revival Studios for the info about Chip8
- greatxerox, for his time and emulation tests on the CPC (and other bugs)
- Thanks to Bruno Kukulcan and Megachur for some Amstrad CPC IPF files for testing
- Thanks to Francisco Jos� Mart� Terr�n for general bug discover, tests and preview images
- And many pages from Internet, many documents ... and people who I forget, thank you all.

5-. Copyright
-------------
- The Coleco and Pooyan has been rewrited from the originals by Michael Franzen.
- The CPS1 has been rewrited from the original by Tomas Walker.
- The source code for the Lensloc protection simulation comes from Simon Owen.
- All the drivers, the Z80 core, M6502 core, M6809 (HD6309) core, M68000 core, M680X core, TMS-32010 core, NEC v20/v30/v33 core, LR35902 core, M6805 core, MCS51 core, Hu6280 core and MB88XX core are writed by me, Leniad.
- AY-3-891X emulator is a conversion from Chris Cowley, but the original emulator come from MAME team.
- SN76496, YM2203, TMS36XX, VLM-5030, YM3812/YM3526, YM2151, i8255, OKI6295, UPD7759, Z80PIO, Z80CTC, NES sound emulator, pokey and Sega VDP emulators are a conversion writed by me from MAME original.
- TMS99XX emulator have been rewrited from the original by Michael Franzen and have parts from MAME.
- NEC765 emulator is a conversion writed and adapted by me, from MESS original.
All Spectrum, CPC464, CPC664 and CPC6128 roms are copyright of Amstrad.

6-. Contact & Links
-------------------
If you want to contact me to send me some feedback or anything, just use leniad2[@]hotmail.com
You can download the official version and WIP versions from GitHub page https://github.com/leniad/dsp-emulator

If you want info...
www.mamedev.org
www.aarongiles.com
www.emulatronia.com
www.emulation9.com

if you want spectrum tapes, snapshot, info...
www.worldofspectrum.org
trastero.speccy.org
spa2.speccy.org